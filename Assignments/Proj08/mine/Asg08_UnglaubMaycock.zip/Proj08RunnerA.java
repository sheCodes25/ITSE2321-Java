import java.awt.Color;
import java.io.PrintStream;

class Proj08RunnerA
  extends Proj08
{
  private int data;
  private String nameA = "Petra Unglaub-Maycock";
  private String nameB = "p1636626";
  private Color backgroundColor = Color.BLUE;
  
  Proj08RunnerA(int paramInt)
  {
    System.out.println("Proj08");
    System.out.println(this.nameA);
    this.data = paramInt;
  }
  
  Object[] getData()
  {
    Object[] arrayOfObject = new Object[3];
    arrayOfObject[0] = this.nameB;
    arrayOfObject[1] = ("" + this.data);
    arrayOfObject[2] = this.backgroundColor;
    return arrayOfObject;
  }
}
