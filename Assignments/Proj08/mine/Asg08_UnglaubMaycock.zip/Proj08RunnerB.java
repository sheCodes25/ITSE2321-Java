class Proj08RunnerB
{
  void getDataFromObj(Object paramObject)
  {
    Object[] arrayOfObject = ((Proj08RunnerA)paramObject).getData();
    
    new Proj08Graphic(arrayOfObject).run();
  }
}
