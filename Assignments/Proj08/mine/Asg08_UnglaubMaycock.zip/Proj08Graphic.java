import java.awt.Color;

class Proj08Graphic
{
  Object[] array;
  
  Proj08Graphic(Object[] paramArrayOfObject)
  {
    this.array = paramArrayOfObject;
  }
  
  void run()
  {
    Picture localPicture = new Picture(350, 125);
    localPicture.setAllPixelsToAColor((Color)this.array[2]);
    
    localPicture.addMessage("I certify that this program is my own work", 10, 20);
    
    localPicture.addMessage("and is not the work of others. I agree not", 10, 38);
    
    localPicture.addMessage("to share my solution with others.", 10, 56);
    localPicture.addMessage("Petra Unglaub-Maycock.", 10, 74);
    
    localPicture.addMessage((String)this.array[0], 10, 92);
    localPicture.addMessage((String)this.array[1], 10, 110);
    localPicture.show();
  }
}
