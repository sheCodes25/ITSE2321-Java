import java.awt.Color;
import java.io.PrintStream;

class Proj03Runner
{

    private Picture pic;
    private double scale;
    private int yIntercept;
    private boolean scaleRightOfCubicLine;
    private Color cubicLineColor;
    private int cubicLineHalfWidth;

    Proj03Runner()
    {
        pic = new Picture("Proj03a.bmp");
        scale = (double)(-pic.getHeight()) / 2.2000000000000002D;
        yIntercept = pic.getHeight() / 2;
        scaleRightOfCubicLine = false;
        cubicLineColor = Color.BLACK;
        cubicLineHalfWidth = 10;
        System.out.println("Petra Unglaub-Maycock.");
    }

    Picture getPicture()
    {
        return pic;
    }

    void run()
    {
        int i = pic.getHeight();
        int j = pic.getWidth();
        for(int k = 0; k < pic.getWidth(); k++)
        {
            for(int l = 0; l < pic.getHeight(); l++)
            {
                Pixel pixel = pic.getPixel(k, l);
                int i1 = pixel.getRed();
                int j1 = pixel.getGreen();
                int k1 = pixel.getBlue();
                double d = 1.0D;
                double d1 = (double)k / (double)j;
                double d2 = (double)(j - k) / (double)j;
                double d3 = cubic((double)(k - pic.getWidth() / 2) / (double)(pic.getWidth() / 2));
                double d4 = scale * d3 + (double)yIntercept;
                if((double)l < d4 + (double)cubicLineHalfWidth && (double)l > d4 - (double)cubicLineHalfWidth)
                {
                    pixel.setColor(cubicLineColor);
                    continue;
                }
                if((double)l > d4 && scaleRightOfCubicLine)
                {
                    pixel.setRed((int)((double)i1 * d));
                    pixel.setGreen((int)((double)j1 * d1));
                    pixel.setBlue((int)((double)k1 * d2));
                    continue;
                }
                if((double)l < d4 && !scaleRightOfCubicLine)
                {
                    pixel.setRed((int)((double)i1 * d));
                    pixel.setGreen((int)((double)j1 * d1));
                    pixel.setBlue((int)((double)k1 * d2));
                }
            }

        }

        pic.addMessage("I certify that this program is my own work", 10, 20);
        pic.addMessage("and is not the work of others. I agree not", 10, 38);
        pic.addMessage("to share my solution with others.", 10, 56);
        pic.addMessage("Petra Unglaub-Maycock.", 10, 74);
        pic.explore();
    }

    private double cubic(double d)
    {
        double d1 = d * d * d;
        return d1;
    }
}
