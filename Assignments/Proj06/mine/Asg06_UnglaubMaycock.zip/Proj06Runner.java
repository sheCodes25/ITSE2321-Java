import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.io.PrintStream;

class Proj06Runner extends Proj06
{

    private int flipCode;
    private boolean flipBeforeRotate;

    Proj06Runner()
    {
        flipCode = 0;
        flipBeforeRotate = false;
        System.out.println("Petra Unglaub-Maycock.");
    }

    void run(double d)
    {
        if(flipBeforeRotate)
        {
            pic.addMessage("I certify that this program is my own work", 10, 20);
            pic.addMessage("and is not the work of others. I agree not", 10, 38);
            pic.addMessage("to share my solution with others.", 10, 56);
            pic.addMessage("Print your name here.", 10, 74);
            pic = flip(pic);
            pic = rotatePicture(pic, d);
        } else
        {
            pic.addMessage("I certify that this program is my own work", 10, 20);
            pic.addMessage("and is not the work of others. I agree not", 10, 38);
            pic.addMessage("to share my solution with others.", 10, 56);
            pic.addMessage("Print your name here.", 10, 74);
            pic = rotatePicture(pic, d);
            pic = flip(pic);
        }
    }

    void run(int i)
    {
        pic.addMessage("I certify that this program is my own work", 10, 20);
        pic.addMessage("and is not the work of others. I agree not", 10, 38);
        pic.addMessage("to share my solution with others.", 10, 56);
        pic.addMessage("Petra Unglaub-Maycock.", 10, 74);
        pic = rotatePicture(pic, i);
    }

    private Picture flip(Picture picture)
    {
        AffineTransform affinetransform = new AffineTransform();
        if(flipCode == 0)
        {
            affinetransform.scale(-1D, 1.0D);
        } else
        if(flipCode == 1)
        {
            affinetransform.scale(1.0D, -1D);
        } else
        {
            affinetransform.scale(-1D, -1D);
        }
        int i = picture.getWidth();
        int j = picture.getHeight();
        AffineTransform affinetransform1 = new AffineTransform();
        if(flipCode == 0)
        {
            affinetransform1.translate(i, 0.0D);
        } else
        if(flipCode == 1)
        {
            affinetransform1.translate(0.0D, j);
        } else
        {
            affinetransform1.translate(i, j);
        }
        affinetransform1.concatenate(affinetransform);
        Picture picture1 = new Picture(i, j);
        Graphics2D graphics2d = (Graphics2D)picture1.getGraphics();
        graphics2d.drawImage(picture.getImage(), affinetransform1, null);
        return picture1;
    }

    private Picture rotatePicture(Picture picture, double d)
    {
        AffineTransform affinetransform = new AffineTransform();
        affinetransform.rotate(Math.toRadians(d), picture.getWidth() / 2, picture.getHeight() / 2);
        Rectangle2D rectangle2d = picture.getTransformEnclosingRect(affinetransform);
        int i = (int)rectangle2d.getWidth();
        int j = (int)rectangle2d.getHeight();
        AffineTransform affinetransform1 = new AffineTransform();
        affinetransform1.translate((i - picture.getWidth()) / 2, (j - picture.getHeight()) / 2);
        affinetransform1.concatenate(affinetransform);
        Picture picture1 = new Picture(i, j);
        Graphics2D graphics2d = (Graphics2D)picture1.getGraphics();
        graphics2d.drawImage(picture.getImage(), affinetransform1, null);
        return picture1;
    }
}
