import java.awt.Color;

class Proj07Graphic
{
  void run(String paramString1, String paramString2, Color paramColor)
  {
    Picture localPicture = new Picture(350, 125);
    localPicture.setAllPixelsToAColor(paramColor);
    
    localPicture.addMessage("I certify that this program is my own work", 10, 20);
    
    localPicture.addMessage("and is not the work of others. I agree not", 10, 38);
    
    localPicture.addMessage("to share my solution with others.", 10, 56);
    localPicture.addMessage("Petra Unglaub-Maycock.", 10, 74);
    
    localPicture.addMessage(paramString1, 10, 92);
    localPicture.addMessage(paramString2, 10, 118);
    localPicture.show();
  }
}