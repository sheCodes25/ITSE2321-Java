import java.awt.Color;
import java.io.PrintStream;

class Proj07Runner
  extends Proj07
{
  private int firstRandomNumber;
  private int secondRandomNumber;
  private String key = "ITSE 2321 asdfg";
  private Color backgroundColor = Color.BLUE;
  
  Proj07Runner(int paramInt)
  {
    System.out.println("Proj07");
    System.out.println("Petra");
    this.firstRandomNumber = paramInt;
  }
  
  int getData(int paramInt)
  {
    this.secondRandomNumber = paramInt;
    new Proj07Graphic().run(this.key, "" + this.secondRandomNumber, this.backgroundColor);
    
    return this.firstRandomNumber;
  }
  
  public String toString()
  {
    return "Unglaub-Maycock";
  }
}