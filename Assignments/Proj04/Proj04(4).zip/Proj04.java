//34567890123456789012345678901234567890123456789012345678
/*File Proj04 Copyright 2008 R.G.Baldwin
*********************************************************/
import java.awt.Color;
class Proj04{
  //DO NOT MODIFY THE CODE IN THIS CLASS DEFINITION.
  public static void main(String[] args){
    Picture pic = new Proj04Runner().run();
    System.out.println(pic);
  }//end main method
}//end class Proj04
//End program specifications.