import java.awt.Color;
import java.io.PrintStream;

class Proj04Runner
{

    private Picture pix;
    private double scale;
    private boolean mirrorRightOfParabola;
    private boolean mirrorTheTopToBottom;
    private Color parabolaColor;
    private Color verticalLineColor;

    Proj04Runner()
    {
        pix = new Picture("Proj04.jpg");
        scale = (3 * pix.getHeight()) / 8;
        mirrorRightOfParabola = true;
        mirrorTheTopToBottom = false;
        parabolaColor = Color.BLACK;
        verticalLineColor = Color.RED;
        System.out.println("Petra Unglaub-Maycock.");
    }

    Picture run()
    {
        pix.addMessage("I certify that this ", 2, 18);
        pix.addMessage("program is my own", 2, 36);
        pix.addMessage("work and is not the ", 2, 54);
        pix.addMessage("work of others.", 5, 72);
        pix.addMessage("Petra Unglaub-Maycock.", 2, 90);
        pix = mirrorUpperQuads(pix);
        if(mirrorTheTopToBottom)
        {
            pix = mirrorTopToBottom(pix);
        } else
        {
            pix = copyTopToBottom(pix);
        }
        pix = invertBottomHalf(pix);
        pix.explore();
        return pix;
    }

    private Picture mirrorUpperQuads(Picture picture)
    {
        Object obj = null;
        Object obj1 = null;
        int i = picture.getWidth() / 2;
        int j = picture.getWidth();
        for(int k = 0; k < picture.getHeight() / 2; k++)
        {
            for(int l = 0; l <= i; l++)
            {
                double d = parabola((double)l / (double)(picture.getWidth() / 2));
                d = scale * d;
                if(k == (int)d)
                {
                    Pixel pixel = picture.getPixel(l, k);
                    Pixel pixel4 = picture.getPixel(j - 1 - l, k);
                    pixel.setColor(parabolaColor);
                    pixel4.setColor(parabolaColor);
                    continue;
                }
                if(l == i)
                {
                    Pixel pixel1 = picture.getPixel(l, k);
                    Pixel pixel5 = picture.getPixel(j - 1 - l, k);
                    pixel1.setColor(verticalLineColor);
                    pixel5.setColor(verticalLineColor);
                    continue;
                }
                if(k < (int)d && mirrorRightOfParabola)
                {
                    Pixel pixel2 = picture.getPixel(l, k);
                    Pixel pixel6 = picture.getPixel(j - 1 - l, k);
                    pixel6.setColor(pixel2.getColor());
                    continue;
                }
                if(k > (int)d && !mirrorRightOfParabola)
                {
                    Pixel pixel3 = picture.getPixel(l, k);
                    Pixel pixel7 = picture.getPixel(j - 1 - l, k);
                    pixel7.setColor(pixel3.getColor());
                }
            }

        }

        return picture;
    }

    private Picture mirrorTopToBottom(Picture picture)
    {
        Object obj = null;
        Object obj1 = null;
        int i = picture.getHeight() / 2;
        int j = picture.getHeight();
        for(int k = 0; k < picture.getWidth(); k++)
        {
            for(int l = 0; l < i; l++)
            {
                Pixel pixel = picture.getPixel(k, l);
                Pixel pixel1 = picture.getPixel(k, j - 1 - l);
                pixel1.setColor(pixel.getColor());
            }

        }

        return picture;
    }

    private Picture copyTopToBottom(Picture picture)
    {
        Object obj = null;
        Object obj1 = null;
        int i = picture.getHeight() / 2;
        int j = picture.getHeight();
        for(int k = 0; k < picture.getWidth(); k++)
        {
            for(int l = 0; l < i; l++)
            {
                Pixel pixel = picture.getPixel(k, l);
                Pixel pixel1 = picture.getPixel(k, j / 2 + l);
                pixel1.setColor(pixel.getColor());
            }

        }

        return picture;
    }

    private Picture invertBottomHalf(Picture picture)
    {
        Object obj = null;
        boolean flag = false;
        boolean flag1 = false;
        boolean flag2 = false;
        int l = picture.getHeight() / 2;
        int i1 = picture.getHeight();
        for(int j1 = 0; j1 < picture.getWidth(); j1++)
        {
            for(int k1 = l; k1 < i1; k1++)
            {
                Pixel pixel = picture.getPixel(j1, k1);
                int i = pixel.getRed();
                int j = pixel.getGreen();
                int k = pixel.getBlue();
                pixel.setColor(new Color(255 - i, 255 - j, 255 - k));
            }

        }

        return picture;
    }

    private double parabola(double d)
    {
        double d1 = d * d;
        return d1;
    }
}
