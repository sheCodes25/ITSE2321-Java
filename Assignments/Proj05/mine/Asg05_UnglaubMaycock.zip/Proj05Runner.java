import java.awt.Color;
import java.io.PrintStream;

class Proj05Runner extends Proj05
{

    private Picture skater;
    private Picture hole;
    private Picture snowScene;
    private double scale;
    private int yIntercept;
    private int penWidth;
    private Color penColor;
    private double redScale;
    private double greenScale;
    private double blueScale;
    private int centeringOffset;

    Proj05Runner()
    {
        skater = new Picture("Proj05a.bmp");
        hole = new Picture("Proj05b.bmp");
        snowScene = new Picture("Proj05c.jpg");
        scale = 4 * snowScene.getHeight();
        yIntercept = snowScene.getHeight() / 6;
        penWidth = 8;
        penColor = Color.GREEN;
        redScale = 0.0D;
        greenScale = 1.25D;
        blueScale = 0.0D;
        centeringOffset = 17;
        System.out.println("Petra Unglaub-Maycock.");
    }

    void run()
    {
        skater = crop(skater, 6, 59, 392, 293);
        hole = crop(hole, 6, 59, 392, 293);
        snowScene = crop(snowScene, 6, 59, 392, 293);
        darkenBackground(hole, snowScene);
        colorTint(skater);
        greenScreenDraw(skater, snowScene, 0, 0);
        Turtle turtle = new Turtle(snowScene);
        turtle.setPenColor(penColor);
        turtle.setPenWidth(penWidth);
        turtle.penUp();
        for(int i = 0; i < snowScene.getWidth(); i++)
        {
            for(int j = 0; j < snowScene.getHeight(); j++)
            {
                Pixel pixel = snowScene.getPixel(i, j);
                double d = parabola((double)(i - snowScene.getWidth() / 2) / (double)(snowScene.getWidth() / 2));
                double d1 = scale * d + (double)yIntercept;
                if(j == (int)d1)
                {
                    turtle.moveTo(i + centeringOffset, j);
                    turtle.penDown();
                }
            }

        }

        snowScene.addMessage("I certify that this program is my own work", 10, 60);
        snowScene.addMessage("and is not the work of others. I agree not", 10, 78);
        snowScene.addMessage("to share my solution with others.", 10, 96);
        snowScene.addMessage("Petra Unglaub-Maycock.", 10, 114);
        snowScene.explore();
    }

    private void colorTint(Picture picture)
    {
        Pixel apixel[] = picture.getPixels();
        Object obj = null;
        boolean flag = false;
        boolean flag1 = false;
        boolean flag2 = false;
        for(int l = 0; l < apixel.length; l++)
        {
            Color color = apixel[l].getColor();
            if(color.equals(Color.GREEN))
            {
                continue;
            }
            int i = color.getRed();
            if((double)i * redScale < 255D)
            {
                i = (int)((double)i * redScale);
            } else
            {
                i = 255;
            }
            int j = color.getGreen();
            if((double)j * greenScale < 255D)
            {
                j = (int)((double)j * greenScale);
            } else
            {
                j = 255;
            }
            int k = color.getBlue();
            if((double)k * blueScale < 255D)
            {
                k = (int)((double)k * blueScale);
            } else
            {
                k = 255;
            }
            apixel[l].setColor(new Color(i, j, k));
        }

    }

    private void darkenBackground(Picture picture, Picture picture1)
    {
        Pixel apixel[] = picture.getPixels();
        Pixel apixel1[] = picture1.getPixels();
        Object obj = null;
        boolean flag = false;
        boolean flag1 = false;
        boolean flag2 = false;
        for(int l = 0; l < apixel.length; l++)
        {
            Color color = apixel[l].getColor();
            if(color.equals(Color.GREEN))
            {
                color = apixel1[l].getColor();
                apixel1[l].setColor(color.darker());
                continue;
            }
            color = apixel1[l].getColor();
            int i = color.getRed();
            if((double)i * redScale < 255D)
            {
                i = (int)((double)i * redScale);
            } else
            {
                i = 255;
            }
            int j = color.getGreen();
            if((double)j * greenScale < 255D)
            {
                j = (int)((double)j * greenScale);
            } else
            {
                j = 255;
            }
            int k = color.getBlue();
            if((double)k * blueScale < 255D)
            {
                k = (int)((double)k * blueScale);
            } else
            {
                k = 255;
            }
            apixel1[l].setColor(new Color(i, j, k));
        }

    }

    private void greenScreenDraw(Picture picture, Picture picture1, int i, int j)
    {
        int k = picture.getWidth();
        int l = picture.getHeight();
        Object obj = null;
        Object obj1 = null;
        for(int i1 = 0; i1 < l; i1++)
        {
            for(int j1 = 0; j1 < k; j1++)
            {
                Color color = picture.getPixel(j1, i1).getColor();
                if(!color.equals(Color.GREEN))
                {
                    Pixel pixel = picture1.getPixel(i + j1, j + i1);
                    pixel.setColor(color);
                }
            }

        }

    }

    private Picture crop(Picture picture, int i, int j, int k, int l)
    {
        Picture picture1 = new Picture(k, l);
        int i1 = 0;
        int j1 = 0;
        boolean flag = false;
        boolean flag1 = false;
        Object obj = null;
        Object obj1 = null;
        for(int k1 = i; k1 < i + k; k1++)
        {
            for(int l1 = j; l1 < j + l; l1++)
            {
                Color color = picture.getPixel(k1, l1).getColor();
                Pixel pixel = picture1.getPixel(i1, j1);
                pixel.setColor(color);
                j1++;
            }

            j1 = 0;
            i1++;
        }

        return picture1;
    }

    private double parabola(double d)
    {
        double d1 = d * d;
        return d1;
    }
}
