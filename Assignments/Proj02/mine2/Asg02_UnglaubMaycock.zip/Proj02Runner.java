import java.awt.Color;
import java.io.PrintStream;

class Proj02Runner
{
  private Picture pic = new Picture("Proj02.jpg");
  private double slope = -0.25D;
  private int yIntercept = 3 * this.pic.getHeight() / 4;
  private Color lineColor = Color.GREEN;
  private boolean invertRightSide = true;
  private int blueValue = 64;
  
  Proj02Runner()
  {
    System.out.println("Petra Unglaub-Maycock.");
  }
  
  Picture getPicture()
  {
    return this.pic;
  }
  
  void run()
  {
    this.pic.addMessage("I certify that this program is my own work", 10, 20);
    
    this.pic.addMessage("and is not the work of others. I agree not", 10, 38);
    
    this.pic.addMessage("to share my solution with others.", 10, 56);
    this.pic.addMessage("Petra Unglaub-Maycock.", 10, 74);
    
    Pixel localPixel = null;
    int i = this.pic.getWidth();
    for (int j = 0; j < this.pic.getWidth(); j++) {
      for (int k = 0; k < this.pic.getHeight(); k++)
      {
        localPixel = this.pic.getPixel(j, k);
        
        int m = straightLine(this.slope, j, this.yIntercept);
        if ((k >= m - 2) && (k <= m + 2))
        {
          localPixel.setColor(this.lineColor);
        }
        else if ((k > m) && (this.invertRightSide))
        {
          localPixel.setRed(255 - localPixel.getRed());
          localPixel.setGreen(255 - localPixel.getGreen());
          localPixel.setBlue(127);
        }
        else if ((k < m) && (!this.invertRightSide))
        {
          localPixel.setRed(255 - localPixel.getRed());
          localPixel.setGreen(255 - localPixel.getGreen());
          localPixel.setBlue(this.blueValue);
        }
      }
    }
    this.pic.explore();
  }
  
  private int straightLine(double paramDouble, int paramInt1, int paramInt2)
  {
    return (int)(paramDouble * paramInt1 + paramInt2);
  }
}
