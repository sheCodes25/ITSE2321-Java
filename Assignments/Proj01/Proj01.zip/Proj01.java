//34567890123456789012345678901234567890123456789012345678
/*File Proj01 Copyright 2016 R.G.Baldwin
*********************************************************/
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import java.io.IOException;

public class Proj01{
  //DO NOT MODIFY THE CODE IN THIS CLASS DEFINITION.
  public static void main(String[] args){
    Proj01Runner obj = new Proj01Runner();
    obj.run();
    Picture mars = obj.getMars();
    mars.explore();    

    System.out.println(obj.getForceshield());
    System.out.println(obj.getLightsaber());
  
  }//end main
}//end class Proj01
//End program specifications.
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
