

import java.awt.Color;
import java.io.PrintStream;

class Proj01Runner
{
  private Picture mars = new Picture("Proj01.jpg");
  private Turtle forceshield = new Turtle(this.mars);
  private Turtle lightsaber = new Turtle(this.mars);
  private int radius = 103;
  private Color verticalColor = Color.GREEN;
  private Color upperLeftColor = Color.YELLOW;
  private Color lowerLeftColor = Color.RED;
  private Color lightsaberColor = Color.CYAN;
  private Color axesColor = Color.ORANGE;
  
  Proj01Runner()
  {
    System.out.println("Petra Unglaub-Maycock.");
	
}
  
  Turtle getForceshield()
  {
    return this.forceshield;
  }
  
  Turtle getLightsaber()
  {
    return this.lightsaber;
  }
  
  Picture getMars()
  {
    return this.mars;
  }
  
  void run()
  {
    this.mars.addMessage("I certify that this program is my own work", 10, 20);
    
    this.mars.addMessage("and is not the work of others. I agree not", 10, 38);
    
    this.mars.addMessage("to share my solution with others.", 10, 56);
    this.mars.addMessage("Petra Unglaub-Maycock.", 10, 74);

    
    this.forceshield.setName("Forceshield");
    
    this.forceshield.penDown();
    this.forceshield.setPenColor(this.verticalColor);
    this.forceshield.setPenWidth(2);
    this.forceshield.forward(this.radius);
    this.forceshield.turn(90.0D);
    
    this.forceshield.setPenColor(this.upperLeftColor);
    this.forceshield.setPenWidth(3);
    double d1 = 0.0D;
    double d2 = this.radius;
    while (d2 > -this.radius)
    {
      d2 -= 1.0D;
      if (d2 < 0.0D)
      {
        this.forceshield.setPenColor(this.lowerLeftColor);
        this.forceshield.setPenWidth(4);
      }
      d1 = Math.sqrt(this.radius * this.radius - d2 * d2);
      this.forceshield.moveTo((int)(this.mars.getWidth() / 2 - d1), 
        (int)(this.mars.getHeight() / 2 - d2));
    }
    this.lightsaber.setName("Lightsaber");
    this.lightsaber.setPenWidth(3);
    this.lightsaber.setPenColor(this.lightsaberColor);
    this.lightsaber.penUp();
    this.lightsaber.moveTo(190, 166);
    this.lightsaber.penDown();
    this.lightsaber.moveTo(this.mars.getWidth() / 2 - 40, this.mars
      .getHeight() / 2 - 40);
    
    this.forceshield.setPenColor(this.axesColor);
    this.forceshield.setPenWidth(2);
    this.forceshield.penUp();
    this.forceshield.moveTo(this.mars.getWidth() / 2, 0);
    this.forceshield.penDown();
    this.forceshield.moveTo(this.mars.getWidth() / 2, this.mars.getHeight());
    this.forceshield.penUp();
    this.forceshield.moveTo(this.mars.getWidth(), this.mars.getHeight() / 2);
    this.forceshield.penDown();
    this.forceshield.moveTo(0, this.mars.getHeight() / 2);
    this.forceshield.penUp();
    this.forceshield.moveTo(0, this.mars.getHeight() / 2);
    this.forceshield.moveTo(this.mars.getWidth() / 2, this.mars.getHeight() / 2);
  }
}
