import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;

class Proj09Runner
{
  private boolean forwardSort = true;
  
  Proj09Runner()
  {
    System.out.println("I certify that this program is my own work");
    
    System.out.println("and is not the work of others. I agree not");
    
    System.out.println("to share my solution with others.");
    System.out.println("Petra Unglaub-Maycock.");
    System.out.println();
  }
  
  Collection<String> getCollection(String[] paramArrayOfString)
  {
    ArrayList localArrayList = new ArrayList(Arrays.asList(paramArrayOfString));
    if (this.forwardSort) {
      Collections.sort(localArrayList);
    } else {
      Collections.sort(localArrayList, 
        Collections.reverseOrder());
    }
    return localArrayList;
  }
}